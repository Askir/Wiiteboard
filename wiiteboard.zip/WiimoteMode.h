#ifndef WiimoteMode_h
#define WiimoteMode_h
enum WiimoteMode
{
	PRESENTATION_MODE,
	CAMERA_MODE,
	DISABLED_MODE
};
#endif

#include "Coord.h"
Coord::Coord(double x, double y){
	this->x = x;
	this->y = y;
}
#ifndef Coord_h
#define Coord_h


struct Coord{
	double Coord::x;
	double Coord::y;

	Coord::Coord(double x, double y);
};

#endif
#ifndef PenAction_h
#define PenAction_h
enum PenAction
{
	LEFT_CLICK_DOWN,
	LEFT_CLICK_UP,
	RIGHT_CLICK_DOWN,
	RIGHT_CLICK_UP,
	MOVE_MOUSE,
	MOUSE_DISCONNECT,
	NO_ACTION
};
#endif
